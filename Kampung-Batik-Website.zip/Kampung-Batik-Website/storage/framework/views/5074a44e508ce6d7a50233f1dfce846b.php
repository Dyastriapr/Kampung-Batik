<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  </head>
  <body class="">

    <header class="">
        <?php echo $__env->make('partials.beranda.navbar-beranda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <main class="container border border-primary  p-0">
      
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active" data-bs-interval="3500">
            <img src="/img/header.jpg" class="d-block w-100 object-fit-cover" alt="..." style="height:512px ">
            <div class="carousel-caption d-none d-md-block">
              <h3>Selamat Datang</h3>
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="3500">
            <img src="/img/header.jpg" class="d-block w-100 object-fit-cover" alt="..." style="height: 512px">
            <div class="carousel-caption d-none d-md-block">
              <h3>Desa Wisata Kampung Batik Cibuluh</h3>
              <i class="bi bi-geo-alt-fill "></i>
              <span class="">Cibuluh, Bogor Utara, Kota Bogor, Jawa Barat</span>
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="3500">
            <img src="/img/header.jpg" class="d-block w-100 object-fit-cover" alt="..." style="height: 512px">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      
      
      <div class="mt-5 mb-5" style="">
        <div class="row g-5">
          <div class="col-md-6">
            <div class="card text-center rounded-0">
              <i class="bi bi-bag fs-1"></i>
              <div class="card-body">
                <h5 class="card-title">Belanja Produk</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-success">Belanja</a>
              </div>
            </div>
          </div>
          
          <div class="col-md-6">
            <div class="card text-center  rounded-0">
              <i class="bi bi-calendar fs-1"></i>
              <div class="card-body ">
                <h5 class="card-title ">Kunjungan Wisata</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-success">Booking</a>
              </div>
            </div>      
          </div>
        </div>
      </div>

      
      <div class="card  w-100 mb-5  rounded-0" >
        <div class="row g-0">
          <div class="col-md-8 m-auto">
            <div class="card-body">
              <h3 class="card-title">Tentang</h3>
              <p class="card-text">Kampung Batik Cibuluh adalah Sebuah Program Kampung Wisata Edukasi, yang mengembangkan potensi wilayahnya yaitu Batik, melalui Edukasi dan Ekonomi Kreatif yang Terfokus pada Pembedayaan Kaum Ibu sebagai Kontribusi terhadap Kesetaraan Gender di Indonesia.</p>
              <p class="card-text">Kampung Batik Cibuluh di Resmikan pada 24 Agustus 2019 sebagai Kampung Batik pertama di Kota Bogor dan Kawasan Penghasil Batik Cap dan Batik Tulis baik Klasik-Tradisional maupun Kontemporer yang Mengangkat Keanekaragaman Ikon Kota Bogor.</p>
              <p class="card-text">Eksistensi Kampung Batik Cibuluh lebih Mengutamakan kepada Padat Karya dimana dalam Proses Produksi Hampir keseluruhan bersifat Manual dan di dalamnya Menerapkan System Pemberdayaan Masyarakat</p>
              <p class="card-text">Kampung Batik Cibuluh terus Mengupayakan terwujudnya 3 Pilar keselarasan pada Ibu Pembatik, Pertama melalui Kotribusi Positif terhadap Lingkungan, Kedua yaitu Keselarasan Peran Sosial di Masyarakat yang di tandai dengan kekompakan dan kerjasama yang Baik, dan yang Ketiga adalah Keselarasan Ekonomi/ Finansial yang di dapatkan.</p>
            </div>
          </div>
          <div class="col-md-4 border border-primary ">
            <img src="/img/tentang.png" class="img-fluid " alt="..." style="" >
          </div>
        </div>
      </div>

      
      <div class="card w-100 mb-2 text-center rounded-0">
        <div class="card-body">
          <h3 class="card-title">Produk</h3>
        </div>
      </div>
      <div id="carouselExample" class="carousel carousel-dark slide mb-5 rounded-0" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="2" aria-label="Slide 3"></button>
          <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="3" aria-label="Slide 4"></button>

        </div>
        <div class="carousel-inner">
          <div class="carousel-item active" data-bs-interval="5500">
            <div class="card mb-3 w-100 rounded-0">
              <div class="row g-0">
                <div class="col-md-4">
                  <img src="/img/kain.png" class="img-fluid" alt="...">
                </div>
                <div class="col-md-8 m-auto">
                  <div class="card-body text-end">
                    <h5 class="card-title">Kain Batik</h5>
                    <p class="card-text">Kain Batik Tulis yang ukurannya Kurang Lebih 2Meter ini di Produksi para pengrajin Batik di kampung batik cibuluh dengan Brand/ Merk daganngya Masing-masing. dengan mengangkat kearifan lokal Ikon Kota Bogor.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="5500">
            <div class="card mb-3 w-100 rounded-0">
              <div class="row g-0">
                <div class="col-md-4">
                  <img src="/img/pakaian.png" class="img-fluid" alt="...">
                </div>
                <div class="col-md-8 m-auto">
                  <div class="card-body text-end rounded-0">
                    <h5 class="card-title">Pakaian Batik</h5>
                    <p class="card-text">Menjual Pakaian Jadi berupa Baju (Kemeja, Blouse, Dress, Jaket, Outer, Rok) yg di produksi oleh para pengrajin batik di Kampung Batik Cibuluh. dengan Brand/ Merk dagang dari masing-masing Pengrajin.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="5500">
            <div class="card mb-3 w-100 rounded-0">
              <div class="row g-0">
                <div class="col-md-4">
                  <img src="/img/boneka.png" class="img-fluid" alt="...">
                </div>
                <div class="col-md-8 m-auto">
                  <div class="card-body rounded-0 text-end">
                    <h5 class="card-title">Boneka</h5>
                    <p class="card-text">Boneka Perca ini dibuat dari hasil Pemanfaatan Limbah Padat (Kain Perca).</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="card mb-3 w-100 rounded-0" data-bs-interval="5500">
              <div class="row g-0">
                <div class="col-md-4">
                  <img src="/img/tas.png" class="img-fluid " alt="...">
                </div>
                <div class="col-md-8 m-auto">
                  <div class="card-body rounded-0 text-end">
                    <h5 class="card-title">Tas Batik</h5>
                    <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, asperiores!.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      

      <div class="card w-100 mb-2 text-center rounded-0">
        <div class="card-body">
          <h3 class="card-title">Kegiatan</h3>
        </div>
      </div>

      <div id="carouselExample-II" class="carousel carousel-dark slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExample-II" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExample-II" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExample-II" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active" data-bs-interval="6500">
            <div class="card mb-3 w-100 rounded-0">
              <div class="row g-0">
                <div class="col-md-8 m-auto">
                  <div class="card-body">
                    <h5 class="card-title">Pengalaman Membatik</h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                  </div>
                </div>
                <div class="col-md-4 ">
                  <img src="/img/membatik.png" class="img-fluid" alt="...">
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="6500">
            <div class="card mb-3 w-100 rounded-0">
              <div class="row g-0">
                <div class="col-md-8 m-auto">
                  <div class="card-body">
                    <h5 class="card-title">Tarian Nusantara</h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                  </div>
                </div>
                <div class="col-md-4">
                  <img src="/img/tarian.png" class="img-fluid" alt="...">
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item" data-bs-interval="6500">
            <div class="card mb-3 w-100 rounded-0">
              <div class="row g-0">
                <div class="col-md-8 m-auto">
                  <div class="card-body">
                    <h5 class="card-title">Pertunjukan Wayang</h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                    <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                  </div>
                </div>
                <div class="col-md-4">
                  <img src="/img/wayang.png" class="img-fluid" alt="...">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div class="card w-100 mb-4 text-center rounded-0">
        <div class="card-body">
          <h3 class="card-title">Fasilitas</h3>
        </div>
      </div>

      <div class="row row-cols-1 row-cols-md-3 g-4 mb-5">
        <div class="col">
          <div class="card h-100 align-items-center text-center rounded-0">
            <img src="\img\icon\camera_1998342.png" class="card-img-top mt-4" alt="..." style="width: 38px">
            <div class="card-body">
              
              <p class="card-text">Tempat Foto</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100 align-items-center text-center rounded-0">
            <img src="\img\icon\parking_1367366.png" class="card-img-top mt-4" alt="..." style="width: 38px">
            <div class="card-body">
              
              <p class="card-text">Areal Parkir</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100 align-items-center text-center rounded-0">
            <img src="\img\icon\restroom_2388725.png"class="card-img-top mt-4" alt="..." style="width: 38px">
            <div class="card-body">
              
              <p class="card-text">Kamar Mandi Umum</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100 align-items-center text-center rounded-0">
            <img src="\img\icon\bank_757224.png" class="card-img-top mt-4" alt="..." style="width: 38px">
            <div class="card-body">
              
              <p class="card-text">Balai Pertemuan</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100 align-items-center text-center rounded-0">
            <img src="\img\icon\store_4360494.png" class="card-img-top mt-4" alt="..." style="width: 38px"> 
            <div class="card-body">
              
              <p class="card-text">Kios Souvenir</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100 align-items-center text-center rounded-0">
            <img src="\img\icon\mosque_4470186.png" class="card-img-top mt-4" alt="..." style="width: 38px">
            <div class="card-body">
              
              <p class="card-text">Rumah Ibadah</p>
            </div>
          </div>
        </div>
      </div>

      
      <div class="card mb-3 w-100 rounded-0">
        <div class="row g-0">
          <div class="col-md-8">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.75056400475!2d106.82037881477079!3d-6.553142895260332!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69c7bb622dce11%3A0x32705060f0a02275!2sKampung%20Batik%20Cibuluh!5e0!3m2!1sen!2sid!4v1688395445948!5m2!1sen!2sid" class="w-100 h-100" style=""  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" ></iframe>
          </div>
          <div class="col-md-4" >
            <div class="card-body text-end">
              <h5 class="card-title">Lokasi Desa Wisata</h5>
              <p class="card-text">Kampung Batik Cibuluh Jl.Neglasari 1 No.14 RT 03 RW 04,  Kelurahan Cibuluh Kecamatan Bogor Utara, Kota Bogor, Jawa Barat, 16151</p>
              <h5 class="card-title">Contact Person</h5>
              <div class="mb-3">
                <span class="">+628188289180</span>
                <i class="bi bi-telephone"></i>
                <div></div>
                <span class="card-text">kampungcibuluhofficial@gmail.com</span>
                <i class="bi bi-envelope"></i>
              </div>
              <h5 class="card-title">Jam Operasional</h5>
              <p class="card-text">Senin - Minggu : 08.00 - 16.00</p>
            </div>
          </div>
        </div>
      </div>
    </main>

    <footer class="">
        <?php echo $__env->make('partials.beranda.footer-beranda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
  
  </body>
</html><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/beranda.blade.php ENDPATH**/ ?>