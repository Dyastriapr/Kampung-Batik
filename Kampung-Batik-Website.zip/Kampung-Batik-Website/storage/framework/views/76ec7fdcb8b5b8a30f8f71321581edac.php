<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        div.container{
            width: 1080px;
            border: 1px solid red;
            margin: auto;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        #kotak1{
            border: 1px solid black;
            width: 256px;
            height: 256px; 
            margin: 32px;
        }
        #kotak2{
            border: 1px solid black;
            width: 256px;
            height: 256px;
            margin: 32px;
        }
        #kotak3{
            border: 1px solid black;
            width: 256px;
            height: 256px;
            margin: 32px;
        }
        #kotak4{
            border: 1px solid black;
            width: 256px;
            height: 256px;
            margin: 32px; 
        }
        
        #segitiga1{
            border: 1px solid black;
            width: 256px;
            height: 256px; 
            margin: 32px;
        }
        #segitiga2{
            border: 1px solid black;
            width: 256px;
            height: 256px; 
            margin: 32px;
        }
        #segitiga3{
            border: 1px solid black;
            width: 256px;
            height: 256px; 
            margin: 32px;
        }
        #segitiga4{
            border: 1px solid black;
            width: 256px;
            height: 256px; 
            margin: 32px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div id="kotak">
            <div id="kotak1"></div>
            <div id="kotak2"></div>
            <div id="kotak3"></div>
            <div id="kotak4"></div>
        </div>
        <div id="segitiga">
            <div id="segitiga1"></div>
            <div id="segitiga2"></div>
            <div id="segitiga3"></div>
            <div id="segitiga4"></div>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/lb.blade.php ENDPATH**/ ?>