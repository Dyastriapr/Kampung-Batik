

<?php $__env->startSection('container'); ?>
<p>Kegiatan</p>
<a href="/beranda">kembali</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/kegiatan.blade.php ENDPATH**/ ?>