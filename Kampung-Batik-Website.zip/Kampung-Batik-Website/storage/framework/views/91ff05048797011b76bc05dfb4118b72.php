<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <title>Contoh Desain Blog</title>
  <style>
    .blog-post {
      margin-bottom: 20px;
    }
    .blog-post .post-image {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }
    .blog-post .post-title {
      font-size: 24px;
      font-weight: bold;
      margin-top: 10px;
    }
    .blog-post .post-meta {
      color: #888;
    }
    .blog-post .post-content {
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="blog-post">
          <img src="post1.jpg" alt="Post Image" class="post-image">
          <h2 class="post-title">Judul Posting 1</h2>
          <p class="post-meta">Tanggal: 1 Januari 2023</p>
          <p class="post-content">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut tortor eget quam rutrum auctor. Nunc id lorem enim.
          </p>
          <a href="#" class="btn btn-primary">Baca Selengkapnya</a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="blog-post">
          <img src="post2.jpg" alt="Post Image" class="post-image">
          <h2 class="post-title">Judul Posting 2</h2>
          <p class="post-meta">Tanggal: 10 Februari 2023</p>
          <p class="post-content">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut tortor eget quam rutrum auctor. Nunc id lorem enim.
          </p>
          <a href="#" class="btn btn-primary">Baca Selengkapnya</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
<?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/kunjungan/paket.blade.php ENDPATH**/ ?>