<div style="border: solid 1px blue; padding:16px" class="text-center">
    <div>
      Desa Wisata Kampung Batik Cibuluh 2023
    </div>
    
<?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views//partials/footer-beranda.blade.php ENDPATH**/ ?>