<footer style="padding: 10px; text-align:center; letter-spacing:4px; font-size: 16px;">
    Desa Wisata Kampung Batik Cibuluh <br> ©2023
</footer>

<?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/partials/footer.blade.php ENDPATH**/ ?>