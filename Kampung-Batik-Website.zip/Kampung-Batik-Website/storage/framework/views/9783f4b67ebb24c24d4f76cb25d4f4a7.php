<div class="card text-center">
    <div class="card-header">
      Random 2023
    </div><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/latihan/partials-latihan/footer-latihan.blade.php ENDPATH**/ ?>