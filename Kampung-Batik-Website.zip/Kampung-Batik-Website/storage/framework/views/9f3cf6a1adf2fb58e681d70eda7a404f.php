<nav class="navbar bg-body-secondary">
    <div class="container">
      <a class="navbar-brand" href="/beranda">
        <img src="/img/logo.png" alt="Bootstrap" width="64">
      </a>
    </div>
  </nav><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/\partials\kunjungan\navbar-kunjungan.blade.php ENDPATH**/ ?>