<div style="width:1440px;background-color:white">
  <div style="width: 1312px; margin:auto;">
    <nav class="navbar navbar-expand-lg">
      <div  class="container-fluid">  
        <a class="navbar-brand" href="#"><img src="img/logo.png" alt="logo" width="64px"></a>
          <ul  class="navbar-nav">
            <li class="nav-item"> 
              <a class="nav-link" href="#profil" style="color: black">Profil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#kegiatan" style="color: black">kegiatan</a>
            </li> 
            <li class="nav-item">
              <a class="nav-link" href="#fasilitas" style="color: black">fasilitas</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#kontak" style="color: black">Kontak</a>
            </li>
          </ul>
          <span  class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="/"><button>Kunjungan</button></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/"><button>Toko</button></a>
            </li>
          </span>
      </div>
    </nav>
   </div>
</div>
<?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/partials/navbar.blade.php ENDPATH**/ ?>