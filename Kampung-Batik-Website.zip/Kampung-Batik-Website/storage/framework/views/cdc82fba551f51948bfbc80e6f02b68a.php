<div class="card text-center">
    <div class="card-footer bg-body-secondary">
        Desa Wisata Kampung Batik Cibuluh 2023
    </div>
  </div><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/partials/footer-kunjungan.blade.php ENDPATH**/ ?>