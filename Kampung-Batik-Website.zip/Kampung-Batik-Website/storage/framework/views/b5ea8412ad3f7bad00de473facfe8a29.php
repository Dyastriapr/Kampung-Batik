<div style="border:solid 1px blue; background-color:white; ">
  <div >
    <nav class="navbar navbar-expand-lg">
      <div  class="container-fluid">  
        <a class="navbar-brand" href="/beranda"><img src="img/logo.png" alt="logo" width="64px"></a>
          <ul  class="navbar-nav">
            <li class="nav-item"> 
              <a class="nav-link" href="#tentang" >Profil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#kegiatan" >kegiatan</a>
            </li> 
            <li class="nav-item">
              <a class="nav-link" href="#fasilitas">fasilitas</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#kontak">Kontak</a>
            </li>
          </ul>
          <span  class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="/kunjungan/paket"><button>Kunjungan</button></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/"><button>Toko</button></a>
            </li>
          </span>
      </div>
    </nav>
   </div>
</div>
<?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/\partials\beranda\navbar-beranda.blade.php ENDPATH**/ ?>