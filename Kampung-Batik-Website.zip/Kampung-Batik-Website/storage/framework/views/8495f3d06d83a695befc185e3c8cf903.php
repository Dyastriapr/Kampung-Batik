

<?php $__env->startSection('random'); ?>
    <p>random</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('contoh', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/tes.blade.php ENDPATH**/ ?>