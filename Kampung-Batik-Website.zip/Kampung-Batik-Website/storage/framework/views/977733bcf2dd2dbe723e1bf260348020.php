
<?php $__env->startSection('container'); ?>
<p>laman tentang</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.latihan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/latihan/tentang.blade.php ENDPATH**/ ?>