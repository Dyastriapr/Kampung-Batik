


<?php $__env->startSection('container'); ?>
    <div class="tentang">
        <p>Tentang</p>
        <a href="/beranda">kembali</a>
    </div>

<?php $__env->stopSection(); ?> 


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/tentang.blade.php ENDPATH**/ ?>