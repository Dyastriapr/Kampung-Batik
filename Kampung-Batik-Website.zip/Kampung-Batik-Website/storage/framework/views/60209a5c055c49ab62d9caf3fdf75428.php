<div class="navbar">

</div><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/navbar.blade.php ENDPATH**/ ?>