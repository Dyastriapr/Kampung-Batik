

<?php $__env->startSection('container'); ?>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam facere accusantium mollitia quae, similique, eaque quas quasi qui dolores ipsum quia, nam aliquam velit nihil commodi dignissimos exercitationem. Ullam aut ipsa, similique harum facere consectetur illum totam distinctio repellendus natus voluptas dignissimos! Impedit, mollitia molestiae libero quas ad porro saepe?</p>
    <a href="/beranda">kembali ke beranda</a>
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/detail.blade.php ENDPATH**/ ?>