
<footer class="text-center">
  <p> Copyright &copy; 2023</p>
</footer><?php /**PATH D:\Tugas\TugasAkhir\Kampung-Batik\Kampung-Batik-Website\resources\views/\partials\beranda\footer-beranda.blade.php ENDPATH**/ ?>